package comments

//go:embed data.txt // want `\Qdon't use go:embed in _foo files`
