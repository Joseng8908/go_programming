package nested

type Element struct{}
