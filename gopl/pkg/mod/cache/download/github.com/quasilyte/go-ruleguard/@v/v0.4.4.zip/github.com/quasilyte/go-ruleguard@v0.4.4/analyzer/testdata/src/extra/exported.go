package extra

type Value interface{}

func NewValue() Value {
	return 0
}
