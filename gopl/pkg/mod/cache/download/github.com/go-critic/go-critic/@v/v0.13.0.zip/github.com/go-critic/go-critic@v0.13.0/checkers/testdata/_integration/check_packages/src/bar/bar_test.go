package bar

import "testing"

func TestInternal(t *testing.T) {
	_ = "a" < "a"
}
