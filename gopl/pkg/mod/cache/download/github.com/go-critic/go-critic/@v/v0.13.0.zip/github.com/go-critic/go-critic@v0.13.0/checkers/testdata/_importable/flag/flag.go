package flag

func Bool() bool {
	return false
}
