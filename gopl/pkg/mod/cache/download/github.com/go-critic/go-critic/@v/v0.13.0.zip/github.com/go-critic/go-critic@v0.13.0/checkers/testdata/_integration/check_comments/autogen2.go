// This file is auto generated.
package foo
