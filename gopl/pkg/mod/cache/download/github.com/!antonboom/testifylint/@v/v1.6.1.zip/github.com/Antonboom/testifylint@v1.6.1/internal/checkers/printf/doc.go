// Package printf is a patched fork of
// https://github.com/golang/tools/blob/b6235391adb3b7f8bcfc4df81055e8f023de2688/go/analysis/passes/printf/printf.go#L538
//
// Initial discussion:
// https://go-review.googlesource.com/c/tools/+/580555/comments/dfe3ef96_b1b815d5
package printf
