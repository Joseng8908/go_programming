package somepkg

type ChannelType chan int
