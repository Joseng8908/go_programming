// Package main is the build entry point of revive.
package main

import "github.com/mgechev/revive/cli"

func main() {
	cli.RunRevive()
}
