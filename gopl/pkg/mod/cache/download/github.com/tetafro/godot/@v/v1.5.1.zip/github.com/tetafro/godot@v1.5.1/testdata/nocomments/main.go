package main

func main() {
	println("Hello, world!")
}
