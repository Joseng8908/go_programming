# Integration test

Integration test for `getComments` method.

Tags:
- `[DECL]` - line should be extracted by `getComments` with `scope` argument
one of: `DeclScope`, `TopLevelScope`, `AllScope`.
- `[TOP]` - line should be extracted by `getComments` with `scope` argument
one of: `TopLevelScope`, `AllScope`.
- `[ALL]` - line should be extracted by `getComments` with `scope` argument
`AllScope`.
