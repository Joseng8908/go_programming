package testpkg

func fn1() {
	var a = 1
	var b = 2
	const c = 3
	const d = 4

	e := 5
	var f = 6
	g := 7

	_ = a
	_ = b
	_ = c
	_ = d
	_ = e
	_ = f
	_ = g
}
