// Package opaque defines an Analyzer to that detects interfaces that are used
// to abstract a single concrete implementation only.
package opaque
