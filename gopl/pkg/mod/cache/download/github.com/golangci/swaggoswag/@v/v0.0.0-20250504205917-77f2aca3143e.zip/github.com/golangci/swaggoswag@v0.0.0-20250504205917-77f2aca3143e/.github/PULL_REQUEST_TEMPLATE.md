**No modifications will be accepted other than the synchronization of the fork.**

The synchronization of the fork will be done by the golangci-lint maintainers only.
