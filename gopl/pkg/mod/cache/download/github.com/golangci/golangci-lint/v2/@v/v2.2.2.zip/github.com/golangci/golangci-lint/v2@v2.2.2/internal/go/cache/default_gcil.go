package cache

const (
	envGolangciLintCache     = "GOLANGCI_LINT_CACHE"
	envGolangciLintCacheProg = "GOLANGCI_LINT_CACHEPROG"
)
