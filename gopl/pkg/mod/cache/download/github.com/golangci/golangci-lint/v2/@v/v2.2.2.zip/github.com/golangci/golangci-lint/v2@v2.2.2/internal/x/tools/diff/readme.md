# diff

Extracted from `/internal/diff/` (related to `fixer`).
This is just a copy of the code without any changes.

## History

- sync with https://github.com/golang/tools/blob/v0.28.0
