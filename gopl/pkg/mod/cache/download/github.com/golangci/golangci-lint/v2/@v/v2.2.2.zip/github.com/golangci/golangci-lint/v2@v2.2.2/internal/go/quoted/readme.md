# quoted

Extracted from `go/src/cmd/internal/quoted/` (related to `cache`).
This is just a copy of the Go code without any changes.

## History

- https://github.com/golangci/golangci-lint/pull/5576
  - sync go1.24.1 (no change)
- https://github.com/golangci/golangci-lint/pull/5100
  - Move package from `internal/quoted` to `internal/go/quoted`
- https://github.com/golangci/golangci-lint/pull/5098
  - sync go1.23.2
  - sync go1.22.8
  - sync go1.21.13
